﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PSR_Add_Document.Migrations
{
    public partial class Encryp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "EncryptedString",
                table: "Customers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EncryptedString",
                table: "Customers");
        }
    }
}
