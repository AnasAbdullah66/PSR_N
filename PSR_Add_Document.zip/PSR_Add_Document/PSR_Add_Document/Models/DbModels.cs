﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace PSR_Add_Document.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string AccountNumber { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public int Gender { get; set; }
        public string Brn { get; set; }
        public DateTime DOB { get; set; }
        public string EncryptedString { get; set; }
    }

    public class CustomerDbContext : DbContext
    {
        public CustomerDbContext(DbContextOptions<CustomerDbContext> options) : base(options)
        {

        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<OtpVerificationOptions> OtpVerificationOptions { get; set; }
    }
}
