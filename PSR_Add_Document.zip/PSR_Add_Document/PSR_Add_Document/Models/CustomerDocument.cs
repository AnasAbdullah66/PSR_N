﻿namespace PSR_Add_Document.Models
{
    public class CustomerDocument
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string AccountNumber { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public int Gender { get; set; }
        public string Brn { get; set; }
        public DateTime DOB { get; set; }
        public string TinNumber { get; set; }
        public int AssesmentYear { get; set; }
        public IFormFile Document { get; set; }
    }
}
