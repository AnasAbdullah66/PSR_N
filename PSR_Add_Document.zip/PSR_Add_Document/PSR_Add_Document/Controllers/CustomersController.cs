﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Intrinsics.Arm;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using PSR_Add_Document.Models;
using System.Net.Http;

namespace PSR_Add_Document.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerDbContext _context;
        private readonly IConfiguration _configuration;

        public CustomersController(CustomerDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return _context.Customers != null ?
                        View(await _context.Customers.ToListAsync()) :
                        Problem("Entity set 'CustomerDbContext.Customers'  is null.");
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Customer customer)
        {
            
                //_context.Add(customer);
                //await _context.SaveChangesAsync();
                //return RedirectToAction(nameof(Index));
                Customer obj=new Customer();
                //obj.CustomerId = customer.CustomerId;
                obj.CustomerName = customer.CustomerName;
                obj.AccountNumber = customer.AccountNumber;
                obj.Address = customer.Address;
                obj.Gender = customer.Gender;
                obj.Brn = customer.Brn;
                obj.DOB = customer.DOB;
                obj.MobileNumber = customer.MobileNumber;
                obj.EncryptedString = CryptorEngine.Encrypt((obj.CustomerId).ToString(), true);
                _context.Customers.Add(obj);
                _context.SaveChanges();

            
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB")] Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Customers == null)
            {
                return Problem("Entity set 'CustomerDbContext.Customers'  is null.");
            }
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return (_context.Customers?.Any(e => e.CustomerId == id)).GetValueOrDefault();
        }



        //Otp add page

        public IActionResult OTP()
        {
            return View();
        }





        public async Task<IActionResult> Login(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);


        }

        
        public string GenerateOtp()
        {
            Random r = new Random();
            string otpValue = r.Next(10000, 99999).ToString();
            return otpValue.ToString();
        }

        private void SendOtp(string phoneNumber, string otpCode)
        {

        }

        private bool verifyOtp(string enterdOtp, string generateOtp)
        {
            return enterdOtp.Equals(generateOtp);
        }
        
        //public IActionResult SendOTP(string phoneNumber, string otpCode)
        //{
        //    string smsGetWayUrl = "";
        //    smsGetWayUrl = smsGetWayUrl.Replace("{MobileNumber}", phoneNumber)
        //        .Replace("{}", otpCode);

        //    using (HttpClient client = new HttpClient())
        //    {
        //        HttpResponseMessage response=client.GetAsync(smsGetWayUrl).GetAwaiter().GetResult();
        //        if (response.IsSuccessStatusCode)
        //        {
                    
        //        }
        //    }
        //}

        


        [HttpPost]
        public IActionResult SubmitOtp([FromForm] int finalDigit)
        {
            int a = Convert.ToInt32(TempData["otp"]);
            if (finalDigit == null)
            {
                return NoContent();
            }

            else if ((DateTime.Now - Convert.ToDateTime(TempData["timestamp"])).TotalSeconds > 30)
            {
                return BadRequest("OTP Timedout");
            }
            else if (finalDigit.ToString() == Convert.ToString(a))
            {
                return Ok("OTP Accepted");
            }
            else
            {
                return BadRequest("Please Enter Valid OTP");
            }
        }



        public async Task<IActionResult> AddDocument(int? id)
        {

            return View();
            //return RedirectToAction(nameof(Index));
        }



        private string GenerateOTP()
        {
            const int otpLength = 4;
            const string characters = "0123456789";
            var random = new Random();
            var otp = new char[otpLength];

            for (int i = 0; i < otpLength; i++)
            {
                otp[i] = characters[random.Next(characters.Length)];
            }

            return new string(otp);
        }



       
        

        //[HttpPost]
        //public IActionResult Index(Customer model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        string accountSid = _configuration["Twilio:AccountSid"];
        //        string authToken = _configuration["Twilio:AuthToken"];
        //        string twilioPhoneNumber = _configuration["Twilio:PhoneNumber"];

        //        string otp = GenerateOTP();
        //        string message = $"{otp} is your One-Time Password, valid for 10 minutes only. Please do not share your OTP with anyone.";

        //        try
        //        {
        //            TwilioClient.Init(accountSid, authToken);
        //            var twilioMessage = MessageResource.Create(
        //                body: message,
        //                from: new Twilio.Types.PhoneNumber(),
        //                to: new Twilio.Types.PhoneNumber(model.MobileNumber)
        //            );

        //            TempData["OTP"] = otp;
        //            TempData["MobileNumber"] = model.MobileNumber;

        //            return RedirectToAction("VerifyOTP");
        //        }
        //        catch (Exception ex)
        //        {
        //            ModelState.AddModelError("", $"An error occurred while sending the OTP: {ex.Message}");
        //        }
        //    }

        //    return View(model);
        //}

        [HttpPost]
        public IActionResult VerifyOTP(OtpVerificationOptions model)
        {
            if (ModelState.IsValid)
            {
                if (TempData.TryGetValue("OTP", out object otp) &&
                    TempData.TryGetValue("MobileNumber", out object mobileNumber) &&
                    otp.ToString() == model.OTP && mobileNumber.ToString() == model.MobileNumber)
                {
                    TempData.Remove("OTP");
                    TempData.Remove("MobileNumber");

                    ViewBag.SuccessMessage = "OTP verification successful!";
                    return View();
                }

                ModelState.AddModelError("", "Invalid OTP");
            }
            return View(/*model*/);
        }

        [HttpGet]
        public IActionResult VerifyOTP()
        {
            if (TempData.TryGetValue("MobileNumber", out object mobileNumber))
            {
                TempData.Keep("MobileNumber");
                return View(new Customer { MobileNumber = mobileNumber.ToString() });
            }

            return View();
            //return RedirectToAction("Index");
        }

        //public JsonResult SendOTP()
        //{
        //    int otpValue = new Random().Next(100000, 999999);
        //    var status = "";
        //    try
        //    {
        //        string recipient = ConfigurationManager.AppSettings["RecipientNumber"].ToString();
        //        string APIKey = ConfigurationManager.AppSettings["APIKey"].ToString();

        //        string message = "Your OTP Number is " + otpValue + " ( Sent By : Technotips-Ashish )";
        //        String encodedMessage = HttpUtility.UrlEncode(message);

        //        using (var webClient = new WebClient())
        //        {
        //            byte[] response = webClient.UploadValues("https://api.textlocal.in/send/", new NameValueCollection(){

        //                                 {"apikey" , APIKey},
        //                                 {"numbers" , recipient},
        //                                 {"message" , encodedMessage},
        //                                 {"sender" , "TXTLCL"}});

        //            string result = System.Text.Encoding.UTF8.GetString(response);

        //            var jsonObject = JObject.Parse(result);

        //            status = jsonObject["status"].ToString();

        //            Session["CurrentOTP"] = otpValue;
        //        }


        //        return Json(status, JsonRequestBehavior.AllowGet);


        //    }
        //    catch (Exception e)
        //    {

        //        throw (e);

        //    }

        //}

        //public ActionResult EnterOTP()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public JsonResult VerifyOTP(string otp)
        //{
        //    bool result = false;

        //    string sessionOTP = Session["CurrentOTP"].ToString();

        //    if (otp == sessionOTP)
        //    {
        //        result = true;

        //    }

        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}


    }
}
