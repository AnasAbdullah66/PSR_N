﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PSR_Add_Document.Models;

namespace PSR_Add_Document.Controllers
{
    public class OtpController : Controller
    {
        private readonly CustomerDbContext _context;

        public OtpController(CustomerDbContext context)
        {
            _context = context;
        }

        // GET: Otp
        public async Task<IActionResult> Index()
        {
              return _context.OtpVerificationOptions != null ? 
                          View(await _context.OtpVerificationOptions.ToListAsync()) :
                          Problem("Entity set 'CustomerDbContext.OtpVerificationOptions'  is null.");
        }

        // GET: Otp/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.OtpVerificationOptions == null)
            {
                return NotFound();
            }

            var otpVerificationOptions = await _context.OtpVerificationOptions
                .FirstOrDefaultAsync(m => m.OtpVerificationOptionsId == id);
            if (otpVerificationOptions == null)
            {
                return NotFound();
            }

            return View(otpVerificationOptions);
        }

        // GET: Otp/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Otp/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OtpVerificationOptionsId,EnableUrl,Iterations,Size,Length,Expire,OTP,MobileNumber")] OtpVerificationOptions otpVerificationOptions)
        {
            if (ModelState.IsValid)
            {
                _context.Add(otpVerificationOptions);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(otpVerificationOptions);
        }

        // GET: Otp/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.OtpVerificationOptions == null)
            {
                return NotFound();
            }

            var otpVerificationOptions = await _context.OtpVerificationOptions.FindAsync(id);
            if (otpVerificationOptions == null)
            {
                return NotFound();
            }
            return View(otpVerificationOptions);
        }

        // POST: Otp/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("OtpVerificationOptionsId,EnableUrl,Iterations,Size,Length,Expire,OTP,MobileNumber")] OtpVerificationOptions otpVerificationOptions)
        {
            if (id != otpVerificationOptions.OtpVerificationOptionsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(otpVerificationOptions);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OtpVerificationOptionsExists(otpVerificationOptions.OtpVerificationOptionsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(otpVerificationOptions);
        }

        // GET: Otp/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.OtpVerificationOptions == null)
            {
                return NotFound();
            }

            var otpVerificationOptions = await _context.OtpVerificationOptions
                .FirstOrDefaultAsync(m => m.OtpVerificationOptionsId == id);
            if (otpVerificationOptions == null)
            {
                return NotFound();
            }

            return View(otpVerificationOptions);
        }

        // POST: Otp/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.OtpVerificationOptions == null)
            {
                return Problem("Entity set 'CustomerDbContext.OtpVerificationOptions'  is null.");
            }
            var otpVerificationOptions = await _context.OtpVerificationOptions.FindAsync(id);
            if (otpVerificationOptions != null)
            {
                _context.OtpVerificationOptions.Remove(otpVerificationOptions);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OtpVerificationOptionsExists(int id)
        {
          return (_context.OtpVerificationOptions?.Any(e => e.OtpVerificationOptionsId == id)).GetValueOrDefault();
        }
    }
}
